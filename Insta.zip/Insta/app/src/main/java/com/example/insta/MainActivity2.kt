package com.example.insta

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.insta.databinding.ActivityMain2Binding


class MainActivity2 : AppCompatActivity() {

   private lateinit var binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMain2Binding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        emailFocusListener()
        passwordFocusListener()
        setOnClickListener()
    }
        private fun emailFocusListener()
        {
            binding.mailEdittext.setOnFocusChangeListener{_, focused ->
                if (!focused)
                {
                    binding.mailContainer.helperText = validEmail()
                }

            }
        }

    private fun validEmail():String?
    {
        val emailText = binding.mailEdittext.text.toString()
        if(!Patterns.EMAIL_ADDRESS.matcher(emailText).matches())
        {
            return "Invalid Email Address"
        }
        return null
    }
    private fun passwordFocusListener()
    {
        binding.passEdittext.setOnFocusChangeListener{_, focused ->
            if (!focused)
            {
                binding.passContainer.helperText = validPassword()
            }
        }
    }
    private fun validPassword():String?
    {
        val passwordText = binding.passEdittext.text.toString()

        if(passwordText.length < 8)
        {
            return "Minimum 8 Character Password"
        }
        if(!passwordText.matches(".*[A-Z].*".toRegex()))
        {
            return "Must Contain 1 Upper-Case Character"
        }
        if(!passwordText.matches(".*[a-z].*".toRegex()))
        {
            return "Must Contain 1 Lower-Case Character"
        }
        if(!passwordText.matches(".*[!@#$%^&*+=].*".toRegex()))
        {
            return "Must Contain 1 Special Character(!@#$%^&*+=)"
        }
        if(!passwordText.matches(".*[0-9].*".toRegex()))
        {
            return "Must Contain 1 Number"
        }
        return null
    }
    private fun setOnClickListener() {
        binding.submit.setOnClickListener{
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            Toast.makeText(this,"Registered Successfully!!!", Toast.LENGTH_LONG).show()
        }
    }
}
