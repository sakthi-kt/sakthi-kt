package com.example.insta

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        var t1 = findViewById<TextView>(R.id.t1)
        var t2 = findViewById<TextView>(R.id.t2)
        val b =intent.extras
        var a = b!!.getString("key0")
        var c = b!!.getString("key1")
        t1.setText(a)
        t2.setText(c)

    }
}
