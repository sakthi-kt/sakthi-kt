package com.example.insta

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.insta.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var user:EditText
    lateinit var pass :EditText
    private lateinit var binding :ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        user = binding.emailEdittext
        pass = binding.passwordEdittext
        emailFocusListener()
        passwordFocusListener()
        setOnClickListener()
    }

    private fun emailFocusListener()
    {
        binding.emailEdittext.setOnFocusChangeListener{_, focused ->
            if (!focused)
            {
                binding.emailContainer.helperText = validEmail()
            }

        }
    }
    private fun validEmail():String?
    {
        val emailText = binding.emailEdittext.text.toString()
        if(!Patterns.EMAIL_ADDRESS.matcher(emailText).matches())
        {
            return "Invalid Email Address"
        }
        return null
    }


    private fun passwordFocusListener()
    {
        binding.passwordEdittext.setOnFocusChangeListener{_, focused ->
            if (!focused)
            {
                binding.passwordContainer.helperText = validPassword()
            }
        }
    }
    private fun validPassword():String?
    {
        val passwordText = binding.passwordEdittext.text.toString()

        if(passwordText.length < 8)
        {
            return "Minimum 8 Character Password"
        }
        if(!passwordText.matches(".*[A-Z].*".toRegex()))
        {
            return "Must Contain 1 Upper-Case Character"
        }
        if(!passwordText.matches(".*[a-z].*".toRegex()))
        {
            return "Must Contain 1 Lower-Case Character"
        }
        if(!passwordText.matches(".*[!@#$%^&*+=].*".toRegex()))
        {
            return "Must Contain 1 Special Character(!@#$%^&*+=)"
        }
        if(!passwordText.matches(".*[0-9].*".toRegex()))
        {
            return "Must Contain 1 Number"
        }
        return null
    }
    private fun setOnClickListener() {

        binding.create.setOnClickListener {
            val intent = Intent(this,MainActivity2::class.java)
            startActivity(intent)
        }

        binding.loginButton.setOnClickListener {

           val e1 = binding.emailEdittext.text.toString()
           val e2 = binding.passwordEdittext.text.toString()
            if (e1.isEmpty()){
                binding.emailEdittext.error ="Mail Required"
                return@setOnClickListener
            }else if(e2.isEmpty()){
                binding.passwordEdittext.error = "Password Required"
                return@setOnClickListener
            }else{
               Toast.makeText(this,"Loggedin Successfully",Toast.LENGTH_SHORT).show()
            }

            val b = Bundle()
            b.putString("key0",user.text.toString())
            b.putString("key1",pass.text.toString())
            val intent = Intent(this,MainActivity3::class.java)
            intent.putExtras(b)
            startActivity(intent)
        }
    }
}
